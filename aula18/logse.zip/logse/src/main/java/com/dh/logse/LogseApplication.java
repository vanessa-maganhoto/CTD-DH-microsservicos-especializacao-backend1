package com.dh.logse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogseApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogseApplication.class, args);
	}

}
