package com.dh.logse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogseApplicationTests {

	@Test
	void contextLoads() {
	}

}
