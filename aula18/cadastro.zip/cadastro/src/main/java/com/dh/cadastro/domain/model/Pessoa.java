package com.dh.cadastro.domain.model;

public record Pessoa(Long id, String name, String genre) {
}
