package com.dh.cadastroapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
